public record Stadt(String name, String land, int ewz) {}
